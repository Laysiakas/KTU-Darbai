﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

/*Savarankiško darbo užduotis3. 
 Sukurkite metodą, kuris surastų duotame objektų rinkinyje brangiausią dviratį. 
 Papildykite programą veiksmais, kuriais būtų randama, kuriame dviračių nuomos punkte yra 
brangiausias dviratis ir kokia jo piniginė vertė. 
Modifikuojama 3.3 skyriaus programa. */

namespace Uzduotis3
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
