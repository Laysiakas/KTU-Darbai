﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

/*Barboros turimos valiutos surašytos faile B.txt, o Anupro – faile A.txt. Vienoje eilutėje – vienos šalies 
valiutos duomenys: pinigai(pvz., doleriai ir centai) ir kursas, perskaičiuojant į eurus ir centus. Parašykite 
programą, kuri suskaičiuotų, kiek pinigų eurais ir centais turi Barbora ir kiek Anupras atskirai ir kiek abu 
bendrai. */

namespace Uzduotis2
{
    class Program
    {
        static void Main(string[] args)
        {
            
            string barbora = "b.txt"; 
            string anupras = "a.txt"; 

            decimal BarboraEurai = SkaiciuojaVisusPinigus(barbora);
            decimal AnuprasEurai = SkaiciuojaVisusPinigus(anupras);
            decimal Viskas = BarboraEurai + AnuprasEurai;
            Console.WriteLine($"Barbora turi: {BarboraEurai:F2} EUR");
            Console.WriteLine($"Anupras turi: {AnuprasEurai:F2} EUR");
            Console.WriteLine($"Kartu jie turi: {Viskas:F2} EUR");
        }
        static decimal SkaiciuojaVisusPinigus(string Failas)
        {
            decimal VisiEurai = 0;

            using (StreamReader tekstas = new StreamReader(Failas))
            {
                string Linija;
                while ((Linija = tekstas.ReadLine()) != null)
                {
                    string[] p = Linija.Split(' ');
                    int Valiuta = int.Parse(p[0]);      
                    int Centai = int.Parse(p[1]);      
                    decimal Keitykla = decimal.Parse(p[2]); 
                    decimal VisaSuma = Valiuta + (Centai / 100m);
                    decimal VisiPinigaiEurais = VisaSuma * Keitykla;
                    VisiEurai += VisiPinigaiEurais;
                }
            }

            return VisiEurai;
        }
    }
}
